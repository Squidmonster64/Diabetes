import { calculateBolus } from "./calculator.js";
import { Decimal } from "./decimal.js";
import { newId, sha256 } from "./audit.js";
import type { CalculationInput, ClinicianConfiguration } from "./types.js";
import type {
  AdministrationRequest,
  AuditStore,
  CalculationRecord,
  ConfirmationRequest,
  CreatedCalculation,
  WorkflowResponse,
  WorkflowVersions,
} from "./workflow-types.js";

const REVIEW_TTL_MS = 5 * 60 * 1000;

export class BolusWorkflowService {
  readonly #records = new Map<string, CalculationRecord>();

  constructor(private readonly audit: AuditStore) {}

  createCalculation(args: {
    patientId: string;
    configuration: ClinicianConfiguration;
    input: CalculationInput;
    versions: WorkflowVersions;
  }): CreatedCalculation {
    const calculationId = newId();
    const createdAt = args.input.calculatedAt;
    this.appendOrThrow({
      eventId: newId(), eventType: "CALCULATION_STARTED", patientId: args.patientId,
      calculationId, occurredAt: createdAt,
      payload: { input: args.input, versions: args.versions },
    });

    const result = calculateBolus(args.configuration, args.input);
    if (result.status === "REFUSED") {
      const record: CalculationRecord = Object.freeze({
        calculationId, patientId: args.patientId, state: "REFUSED", createdAt,
        configuration: args.configuration, input: args.input, result, versions: args.versions,
      });
      this.appendOrThrow({
        eventId: newId(), eventType: "CALCULATION_REFUSED", patientId: args.patientId,
        calculationId, occurredAt: createdAt, payload: { reasonCode: result.reasonCode },
      });
      this.#records.set(calculationId, record);
      return { record };
    }

    const expiresAt = new Date(Date.parse(createdAt) + REVIEW_TTL_MS).toISOString();
    const record: CalculationRecord = Object.freeze({
      calculationId, patientId: args.patientId, state: result.status, createdAt, expiresAt,
      configuration: args.configuration, input: args.input, result, versions: args.versions,
    });
    const snapshotHash = this.snapshotHash(record);
    this.appendOrThrow({
      eventId: newId(), eventType: "CALCULATION_COMPLETED", patientId: args.patientId,
      calculationId, occurredAt: createdAt,
      payload: { result, expiresAt, snapshotHash },
    });
    this.#records.set(calculationId, record);
    return { record, snapshotHash, displayResult: result };
  }

  confirm(request: ConfirmationRequest): WorkflowResponse {
    const record = this.#records.get(request.calculationId);
    if (!record) return { ok: false, code: "NOT_FOUND" };
    if (record.patientId !== request.patientId) return { ok: false, code: "PATIENT_MISMATCH" };
    if (record.state === "USER_CONFIRMED" || record.state === "ADMINISTRATION_RECORDED") {
      return { ok: false, code: "DUPLICATE_CONFIRMATION" };
    }
    if (record.state === "INVALIDATED") return { ok: false, code: "CALCULATION_INVALIDATED" };
    if (record.state !== "CALCULATED" && record.state !== "CALCULATED_ZERO") {
      return { ok: false, code: "NOT_CONFIRMABLE" };
    }
    if (!record.expiresAt || Date.parse(request.confirmedAt) > Date.parse(record.expiresAt)) {
      const expired = Object.freeze({ ...record, state: "EXPIRED" as const });
      this.#records.set(record.calculationId, expired);
      this.appendOrThrow({ eventId: newId(), eventType: "CALCULATION_EXPIRED", patientId: record.patientId,
        calculationId: record.calculationId, occurredAt: request.confirmedAt, payload: {} });
      return { ok: false, code: "CALCULATION_EXPIRED" };
    }
    if (request.expectedSnapshotHash !== this.snapshotHash(record)) {
      return { ok: false, code: "SNAPSHOT_MISMATCH" };
    }
    const confirmationHash = sha256({ calculationId: record.calculationId, snapshotHash: request.expectedSnapshotHash, confirmedAt: request.confirmedAt });
    const confirmed = Object.freeze({ ...record, state: "USER_CONFIRMED" as const, confirmedAt: request.confirmedAt, confirmationHash });
    this.appendOrThrow({ eventId: newId(), eventType: "CALCULATION_CONFIRMED", patientId: record.patientId,
      calculationId: record.calculationId, occurredAt: request.confirmedAt, payload: { confirmationHash } });
    this.#records.set(record.calculationId, confirmed);
    return { ok: true, record: confirmed };
  }

  invalidate(calculationId: string, patientId: string, occurredAt: string, reason: string): WorkflowResponse {
    const record = this.#records.get(calculationId);
    if (!record) return { ok: false, code: "NOT_FOUND" };
    if (record.patientId !== patientId) return { ok: false, code: "PATIENT_MISMATCH" };
    if (record.state !== "CALCULATED" && record.state !== "CALCULATED_ZERO") return { ok: false, code: "NOT_CONFIRMABLE" };
    const invalidated = Object.freeze({ ...record, state: "INVALIDATED" as const, invalidatedAt: occurredAt, invalidationReason: reason });
    this.appendOrThrow({ eventId: newId(), eventType: "CALCULATION_INVALIDATED", patientId,
      calculationId, occurredAt, payload: { reason } });
    this.#records.set(calculationId, invalidated);
    return { ok: true, record: invalidated };
  }

  recordAdministration(request: AdministrationRequest): WorkflowResponse {
    const record = this.#records.get(request.calculationId);
    if (!record) return { ok: false, code: "NOT_FOUND" };
    if (record.patientId !== request.patientId) return { ok: false, code: "PATIENT_MISMATCH" };
    if (record.state !== "USER_CONFIRMED") return { ok: false, code: "NOT_CONFIRMABLE" };
    try {
      if (Decimal.parse(request.administeredUnits).compare(Decimal.fromInteger(0n)) <= 0 || !Number.isFinite(Date.parse(request.administeredAt))) {
        return { ok: false, code: "INVALID_ADMINISTRATION" };
      }
    } catch {
      return { ok: false, code: "INVALID_ADMINISTRATION" };
    }
    const administered = Object.freeze({ ...record, state: "ADMINISTRATION_RECORDED" as const });
    this.appendOrThrow({ eventId: newId(), eventType: "ADMINISTRATION_RECORDED", patientId: record.patientId,
      calculationId: record.calculationId, occurredAt: request.administeredAt,
      payload: { administeredUnits: request.administeredUnits, calculatedUnits: record.result.status === "REFUSED" ? null : record.result.roundedDoseUnits } });
    this.#records.set(record.calculationId, administered);
    return { ok: true, record: administered };
  }

  get(calculationId: string): CalculationRecord | undefined { return this.#records.get(calculationId); }

  private snapshotHash(record: CalculationRecord): string {
    return sha256({ calculationId: record.calculationId, patientId: record.patientId,
      createdAt: record.createdAt, expiresAt: record.expiresAt, configuration: record.configuration,
      input: record.input, result: record.result, versions: record.versions });
  }

  private appendOrThrow(event: Parameters<AuditStore["append"]>[0]): void {
    try { this.audit.append(event); }
    catch { throw new Error("AUDIT_PERSISTENCE_FAILURE"); }
  }
}
