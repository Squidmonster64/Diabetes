import { Decimal } from "./decimal.js";
import type {
  CalculationInput,
  CalculationResult,
  ClinicianConfiguration,
  RefusalCode,
} from "./types.js";

const ZERO = Decimal.fromInteger(0n);
const MILLISECONDS_PER_HOUR = 3_600_000;

export function calculateBolus(
  configuration: ClinicianConfiguration,
  input: CalculationInput,
): CalculationResult {
  try {
    const parsedConfiguration = parseAndValidateConfiguration(configuration);
    const parsedInput = parseAndValidateInput(configuration, input);

    const refusal = evaluateSafetyGates(parsedConfiguration, parsedInput, input);
    if (refusal) return refused(refusal);

    const carbohydrateComponent = input.mode === "MEAL"
      ? parsedInput.carbohydrateGrams.divide(parsedConfiguration.icr)
      : ZERO;
    const correctionComponent = parsedInput.currentGlucose
      .subtract(parsedConfiguration.targetGlucose)
      .divide(parsedConfiguration.isf);

    const combined = input.mode === "MEAL"
      ? carbohydrateComponent.add(correctionComponent)
      : correctionComponent;
    const rawDose = combined.max(ZERO);

    if (rawDose.compare(parsedConfiguration.maximumDoseUnits) > 0) {
      return refused("MAXIMUM_DOSE_EXCEEDED");
    }

    const roundedDose = rawDose.roundHalfUpToIncrement(parsedConfiguration.doseIncrementUnits);
    if (roundedDose.compare(parsedConfiguration.maximumDoseUnits) > 0) {
      return refused("MAXIMUM_DOSE_EXCEEDED");
    }

    return {
      status: roundedDose.compare(ZERO) === 0 ? "CALCULATED_ZERO" : "CALCULATED",
      carbohydrateComponentUnits: carbohydrateComponent.toCanonicalString(),
      correctionComponentUnits: correctionComponent.toCanonicalString(),
      rawDoseUnits: rawDose.toCanonicalString(),
      roundedDoseUnits: roundedDose.toCanonicalString(),
      doseIncrementUnits: parsedConfiguration.doseIncrementUnits.toCanonicalString(),
      maximumDoseUnits: parsedConfiguration.maximumDoseUnits.toCanonicalString(),
      confirmationRequired: true,
    };
  } catch (error) {
    if (error instanceof ValidationRefusal) return refused(error.reasonCode);
    return refused("ARITHMETIC_FAILURE");
  }
}

function parseAndValidateConfiguration(configuration: ClinicianConfiguration) {
  const parsed = {
    icr: Decimal.parse(configuration.icr),
    isf: Decimal.parse(configuration.isf),
    targetGlucose: Decimal.parse(configuration.targetGlucose),
    insulinDurationHours: Decimal.parse(configuration.insulinDurationHours),
    doseIncrementUnits: Decimal.parse(configuration.doseIncrementUnits),
    maximumDoseUnits: Decimal.parse(configuration.maximumDoseUnits),
    lowGlucoseThreshold: Decimal.parse(configuration.lowGlucoseThreshold),
  };
  if (
    parsed.icr.compare(ZERO) <= 0 ||
    parsed.isf.compare(ZERO) <= 0 ||
    parsed.insulinDurationHours.compare(ZERO) <= 0 ||
    parsed.doseIncrementUnits.compare(ZERO) <= 0 ||
    parsed.maximumDoseUnits.compare(ZERO) <= 0 ||
    parsed.maximumDoseUnits.compare(parsed.doseIncrementUnits) < 0 ||
    parsed.targetGlucose.compare(parsed.lowGlucoseThreshold) <= 0
  ) {
    throw new ValidationRefusal("INVALID_CONFIGURATION");
  }
  return parsed;
}

function parseAndValidateInput(configuration: ClinicianConfiguration, input: CalculationInput) {
  if (input.glucoseUnit !== configuration.glucoseUnit) throw new ValidationRefusal("UNIT_MISMATCH");
  if (!input.glucoseConfirmed) throw new ValidationRefusal("UNCONFIRMED_GLUCOSE");
  if (!input.carbohydratesConfirmed) throw new ValidationRefusal("UNCONFIRMED_CARBOHYDRATES");
  if (!input.recentHistoryComplete) throw new ValidationRefusal("RECENT_BOLUS_HISTORY_INCOMPLETE");

  const currentGlucose = parseInputDecimal(input.currentGlucose);
  const carbohydrateGrams = parseInputDecimal(input.carbohydrateGrams);
  if (currentGlucose.compare(ZERO) <= 0 || carbohydrateGrams.compare(ZERO) < 0) {
    throw new ValidationRefusal("INVALID_INPUT");
  }
  if (input.mode === "MEAL" && carbohydrateGrams.compare(ZERO) <= 0) {
    throw new ValidationRefusal("INVALID_INPUT");
  }
  if (input.mode === "CORRECTION_ONLY" && carbohydrateGrams.compare(ZERO) !== 0) {
    throw new ValidationRefusal("INVALID_INPUT");
  }
  const calculatedAtMs = Date.parse(input.calculatedAt);
  if (!Number.isFinite(calculatedAtMs)) throw new ValidationRefusal("INVALID_INPUT");

  return { currentGlucose, carbohydrateGrams, calculatedAtMs };
}

function evaluateSafetyGates(
  configuration: ReturnType<typeof parseAndValidateConfiguration>,
  parsedInput: ReturnType<typeof parseAndValidateInput>,
  input: CalculationInput,
): RefusalCode | undefined {
  if (input.hypoSymptoms) return "HYPO_SYMPTOMS";
  if (input.duplicateDose) return "DUPLICATE_EVENT_RISK";
  if (input.specialSituations.length > 0) return "SPECIAL_CLINICAL_SITUATION";
  if (parsedInput.currentGlucose.compare(configuration.lowGlucoseThreshold) <= 0) {
    return "HYPO_THRESHOLD";
  }

  for (const priorDose of input.priorRapidActingDoses) {
    const units = parseInputDecimal(priorDose.units);
    const administeredAtMs = Date.parse(priorDose.administeredAt);
    if (units.compare(ZERO) <= 0 || !Number.isFinite(administeredAtMs)) return "INVALID_INPUT";
    const elapsedMs = parsedInput.calculatedAtMs - administeredAtMs;
    if (elapsedMs < 0) return "FUTURE_PRIOR_BOLUS";
    const elapsed = Decimal.fromInteger(BigInt(elapsedMs));
    const duration = configuration.insulinDurationHours.multiply(
      Decimal.fromInteger(BigInt(MILLISECONDS_PER_HOUR)),
    );
    if (elapsed.compare(duration) < 0) return "ACTIVE_PRIOR_BOLUS";
  }
  return undefined;
}

function parseInputDecimal(value: string): Decimal {
  try {
    return Decimal.parse(value);
  } catch {
    throw new ValidationRefusal("INVALID_INPUT");
  }
}

function refused(reasonCode: RefusalCode): CalculationResult {
  return { status: "REFUSED", reasonCode };
}

class ValidationRefusal extends Error {
  constructor(readonly reasonCode: RefusalCode) {
    super(reasonCode);
  }
}
