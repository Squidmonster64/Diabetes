export type GlucoseUnit = "MMOL_L" | "MG_DL";
export type CalculationMode = "MEAL" | "CORRECTION_ONLY";
export type CalculationStatus = "CALCULATED" | "CALCULATED_ZERO" | "REFUSED";

export type RefusalCode =
  | "INVALID_CONFIGURATION"
  | "INVALID_INPUT"
  | "UNIT_MISMATCH"
  | "UNCONFIRMED_GLUCOSE"
  | "UNCONFIRMED_CARBOHYDRATES"
  | "HYPO_THRESHOLD"
  | "HYPO_SYMPTOMS"
  | "RECENT_BOLUS_HISTORY_INCOMPLETE"
  | "ACTIVE_PRIOR_BOLUS"
  | "FUTURE_PRIOR_BOLUS"
  | "DUPLICATE_EVENT_RISK"
  | "SPECIAL_CLINICAL_SITUATION"
  | "MAXIMUM_DOSE_EXCEEDED"
  | "ARITHMETIC_FAILURE";

export interface ClinicianConfiguration {
  readonly icr: string;
  readonly isf: string;
  readonly targetGlucose: string;
  readonly insulinDurationHours: string;
  readonly doseIncrementUnits: string;
  readonly maximumDoseUnits: string;
  readonly lowGlucoseThreshold: string;
  readonly glucoseUnit: GlucoseUnit;
}

export interface PriorRapidActingDose {
  readonly units: string;
  readonly administeredAt: string;
}

export interface CalculationInput {
  readonly mode: CalculationMode;
  readonly currentGlucose: string;
  readonly glucoseUnit: GlucoseUnit;
  readonly glucoseConfirmed: boolean;
  readonly carbohydrateGrams: string;
  readonly carbohydratesConfirmed: boolean;
  readonly recentHistoryComplete: boolean;
  readonly priorRapidActingDoses: readonly PriorRapidActingDose[];
  readonly hypoSymptoms: boolean;
  readonly duplicateDose: boolean;
  readonly specialSituations: readonly string[];
  readonly calculatedAt: string;
}

export interface SuccessfulCalculation {
  readonly status: "CALCULATED" | "CALCULATED_ZERO";
  readonly carbohydrateComponentUnits: string;
  readonly correctionComponentUnits: string;
  readonly rawDoseUnits: string;
  readonly roundedDoseUnits: string;
  readonly doseIncrementUnits: string;
  readonly maximumDoseUnits: string;
  readonly confirmationRequired: true;
}

export interface RefusedCalculation {
  readonly status: "REFUSED";
  readonly reasonCode: RefusalCode;
}

export type CalculationResult = SuccessfulCalculation | RefusedCalculation;
