import type { CalculationInput, CalculationResult, ClinicianConfiguration, SuccessfulCalculation } from "./types.js";

export type WorkflowState =
  | "REFUSED"
  | "CALCULATED"
  | "CALCULATED_ZERO"
  | "USER_CONFIRMED"
  | "EXPIRED"
  | "INVALIDATED"
  | "ADMINISTRATION_RECORDED";

export type AuditEventType =
  | "CALCULATION_STARTED"
  | "CALCULATION_REFUSED"
  | "CALCULATION_COMPLETED"
  | "CALCULATION_CONFIRMED"
  | "CALCULATION_EXPIRED"
  | "CALCULATION_INVALIDATED"
  | "ADMINISTRATION_RECORDED";

export interface WorkflowVersions {
  readonly configurationId: string;
  readonly configurationVersion: number;
  readonly calculatorVersion: string;
  readonly safetyPolicyVersion: string;
}

export interface AuditEvent {
  readonly sequence: number;
  readonly eventId: string;
  readonly eventType: AuditEventType;
  readonly patientId: string;
  readonly calculationId: string;
  readonly occurredAt: string;
  readonly payload: Readonly<Record<string, unknown>>;
  readonly previousHash: string | null;
  readonly eventHash: string;
}

export interface AuditStore {
  append(event: Omit<AuditEvent, "sequence" | "previousHash" | "eventHash">): AuditEvent;
  listForCalculation(calculationId: string): readonly AuditEvent[];
  verifyChain(): boolean;
}

export interface CalculationRecord {
  readonly calculationId: string;
  readonly patientId: string;
  readonly state: WorkflowState;
  readonly createdAt: string;
  readonly expiresAt?: string;
  readonly configuration: ClinicianConfiguration;
  readonly input: CalculationInput;
  readonly result: CalculationResult;
  readonly versions: WorkflowVersions;
  readonly confirmationHash?: string;
  readonly confirmedAt?: string;
  readonly invalidatedAt?: string;
  readonly invalidationReason?: string;
}

export interface ConfirmationRequest {
  readonly calculationId: string;
  readonly patientId: string;
  readonly confirmed: true;
  readonly confirmationTextAccepted: true;
  readonly confirmedAt: string;
  readonly expectedSnapshotHash: string;
}

export interface AdministrationRequest {
  readonly calculationId: string;
  readonly patientId: string;
  readonly administeredUnits: string;
  readonly administeredAt: string;
}

export interface WorkflowSuccess {
  readonly ok: true;
  readonly record: CalculationRecord;
}

export interface WorkflowFailure {
  readonly ok: false;
  readonly code:
    | "NOT_FOUND"
    | "PATIENT_MISMATCH"
    | "NOT_CONFIRMABLE"
    | "CALCULATION_EXPIRED"
    | "CALCULATION_INVALIDATED"
    | "SNAPSHOT_MISMATCH"
    | "DUPLICATE_CONFIRMATION"
    | "AUDIT_PERSISTENCE_FAILURE"
    | "INVALID_ADMINISTRATION";
}

export type WorkflowResponse = WorkflowSuccess | WorkflowFailure;

export interface CreatedCalculation {
  readonly record: CalculationRecord;
  readonly snapshotHash?: string;
  readonly displayResult?: SuccessfulCalculation;
}
