import { createHash, randomUUID } from "node:crypto";
import type { AuditEvent, AuditStore } from "./workflow-types.js";

function canonicalise(value: unknown): string {
  if (value === null || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(canonicalise).join(",")}]`;
  const object = value as Record<string, unknown>;
  return `{${Object.keys(object).sort().map((key) => `${JSON.stringify(key)}:${canonicalise(object[key])}`).join(",")}}`;
}

export function sha256(value: unknown): string {
  return createHash("sha256").update(canonicalise(value)).digest("hex");
}

export function newId(): string {
  return randomUUID();
}

export class InMemoryAppendOnlyAuditStore implements AuditStore {
  readonly #events: AuditEvent[] = [];

  append(event: Omit<AuditEvent, "sequence" | "previousHash" | "eventHash">): AuditEvent {
    const previousHash = this.#events.at(-1)?.eventHash ?? null;
    const sequence = this.#events.length + 1;
    const eventHash = sha256({ sequence, previousHash, ...event });
    const stored = Object.freeze({ ...event, sequence, previousHash, eventHash });
    this.#events.push(stored);
    return stored;
  }

  listForCalculation(calculationId: string): readonly AuditEvent[] {
    return this.#events.filter((event) => event.calculationId === calculationId);
  }

  verifyChain(): boolean {
    let previousHash: string | null = null;
    for (let index = 0; index < this.#events.length; index += 1) {
      const event = this.#events[index];
      if (!event) return false;
      const expected = sha256({
        sequence: event.sequence,
        previousHash,
        eventId: event.eventId,
        eventType: event.eventType,
        patientId: event.patientId,
        calculationId: event.calculationId,
        occurredAt: event.occurredAt,
        payload: event.payload,
      });
      if (event.sequence !== index + 1 || event.previousHash !== previousHash || event.eventHash !== expected) return false;
      previousHash = event.eventHash;
    }
    return true;
  }
}
