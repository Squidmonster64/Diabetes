# Clinical Bolus Calculator — Stage 5

Engineering prototype only. **Not clinically approved and not for treatment use.**

Stage 5 adds a safety-control workflow around the Stage 4 deterministic kernel:

- calculation lifecycle and five-minute confirmation expiry;
- immutable review snapshot hash;
- explicit confirmation with duplicate-confirmation protection;
- input-change invalidation;
- append-only hash-chained audit events;
- refused-result logging without exposing a dose;
- patient binding checks;
- administration recording as a separate event that may differ from the calculated dose.

The in-memory audit store is a test/reference adapter. Production deployment requires durable transactional storage, Supabase RLS, server-authorised configuration handling, and formal clinical/regulatory review.

## Commands

```bash
npm test
npm run check
```
