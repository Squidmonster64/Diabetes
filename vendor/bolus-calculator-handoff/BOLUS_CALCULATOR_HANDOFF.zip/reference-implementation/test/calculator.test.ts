import assert from "node:assert/strict";
import test from "node:test";
import { calculateBolus } from "../src/calculator.js";
import type { CalculationInput, ClinicianConfiguration } from "../src/types.js";

const configuration: ClinicianConfiguration = {
  icr: "10",
  isf: "2",
  targetGlucose: "6",
  insulinDurationHours: "4",
  doseIncrementUnits: "0.5",
  maximumDoseUnits: "20",
  lowGlucoseThreshold: "4",
  glucoseUnit: "MMOL_L",
};

function input(overrides: Partial<CalculationInput> = {}): CalculationInput {
  return {
    mode: "MEAL",
    currentGlucose: "10",
    glucoseUnit: "MMOL_L",
    glucoseConfirmed: true,
    carbohydrateGrams: "40",
    carbohydratesConfirmed: true,
    recentHistoryComplete: true,
    priorRapidActingDoses: [],
    hypoSymptoms: false,
    duplicateDose: false,
    specialSituations: [],
    calculatedAt: "2026-07-24T04:00:00.000Z",
    ...overrides,
  };
}

test("meal dose combines carbohydrate and correction components", () => {
  assert.deepEqual(calculateBolus(configuration, input()), {
    status: "CALCULATED",
    carbohydrateComponentUnits: "4",
    correctionComponentUnits: "2",
    rawDoseUnits: "6",
    roundedDoseUnits: "6",
    doseIncrementUnits: "0.5",
    maximumDoseUnits: "20",
    confirmationRequired: true,
  });
});

test("negative correction reduces meal dose", () => {
  const result = calculateBolus(configuration, input({ currentGlucose: "5", carbohydrateGrams: "40" }));
  assert.equal(result.status, "CALCULATED");
  if (result.status !== "REFUSED") {
    assert.equal(result.correctionComponentUnits, "-0.5");
    assert.equal(result.rawDoseUnits, "3.5");
    assert.equal(result.roundedDoseUnits, "3.5");
  }
});

test("negative final dose clamps to zero", () => {
  const result = calculateBolus(configuration, input({ currentGlucose: "4.1", carbohydrateGrams: "1" }));
  assert.equal(result.status, "CALCULATED_ZERO");
  if (result.status !== "REFUSED") assert.equal(result.roundedDoseUnits, "0");
});

test("correction-only calculation excludes carbohydrate component", () => {
  const result = calculateBolus(configuration, input({ mode: "CORRECTION_ONLY", carbohydrateGrams: "0", currentGlucose: "11" }));
  assert.equal(result.status, "CALCULATED");
  if (result.status !== "REFUSED") {
    assert.equal(result.carbohydrateComponentUnits, "0");
    assert.equal(result.correctionComponentUnits, "2.5");
    assert.equal(result.roundedDoseUnits, "2.5");
  }
});

test("rounds half up to configured increment", () => {
  const custom = { ...configuration, isf: "1000" };
  const result = calculateBolus(custom, input({ currentGlucose: "6", carbohydrateGrams: "42.5" }));
  assert.equal(result.status, "CALCULATED");
  if (result.status !== "REFUSED") assert.equal(result.roundedDoseUnits, "4.5");
});

test("does not round components before summation", () => {
  const result = calculateBolus(configuration, input({ currentGlucose: "6.4", carbohydrateGrams: "43" }));
  assert.equal(result.status, "CALCULATED");
  if (result.status !== "REFUSED") {
    assert.equal(result.carbohydrateComponentUnits, "4.3");
    assert.equal(result.correctionComponentUnits, "0.2");
    assert.equal(result.rawDoseUnits, "4.5");
    assert.equal(result.roundedDoseUnits, "4.5");
  }
});

test("refuses at low threshold", () => {
  assert.deepEqual(calculateBolus(configuration, input({ currentGlucose: "4" })), {
    status: "REFUSED", reasonCode: "HYPO_THRESHOLD",
  });
});

test("permits glucose immediately above low threshold", () => {
  assert.notEqual(calculateBolus(configuration, input({ currentGlucose: "4.000001" })).status, "REFUSED");
});

test("refuses declared hypo symptoms", () => {
  assert.deepEqual(calculateBolus(configuration, input({ hypoSymptoms: true })), {
    status: "REFUSED", reasonCode: "HYPO_SYMPTOMS",
  });
});

test("refuses active prior bolus", () => {
  const result = calculateBolus(configuration, input({ priorRapidActingDoses: [{ units: "3", administeredAt: "2026-07-24T01:00:01.000Z" }] }));
  assert.deepEqual(result, { status: "REFUSED", reasonCode: "ACTIVE_PRIOR_BOLUS" });
});

test("permits prior bolus exactly at duration boundary", () => {
  const result = calculateBolus(configuration, input({ priorRapidActingDoses: [{ units: "3", administeredAt: "2026-07-24T00:00:00.000Z" }] }));
  assert.notEqual(result.status, "REFUSED");
});

test("refuses future prior bolus", () => {
  const result = calculateBolus(configuration, input({ priorRapidActingDoses: [{ units: "3", administeredAt: "2026-07-24T04:00:01.000Z" }] }));
  assert.deepEqual(result, { status: "REFUSED", reasonCode: "FUTURE_PRIOR_BOLUS" });
});

test("refuses when raw dose exceeds maximum", () => {
  const result = calculateBolus(configuration, input({ carbohydrateGrams: "250", currentGlucose: "6" }));
  assert.deepEqual(result, { status: "REFUSED", reasonCode: "MAXIMUM_DOSE_EXCEEDED" });
});

test("refuses when rounding would exceed maximum", () => {
  const custom = { ...configuration, maximumDoseUnits: "4.2", doseIncrementUnits: "0.5" };
  const result = calculateBolus(custom, input({ carbohydrateGrams: "42.5", currentGlucose: "6" }));
  assert.deepEqual(result, { status: "REFUSED", reasonCode: "MAXIMUM_DOSE_EXCEEDED" });
});

test("does not silently cap a maximum-dose breach", () => {
  const result = calculateBolus(configuration, input({ carbohydrateGrams: "250", currentGlucose: "6" }));
  assert.equal("roundedDoseUnits" in result, false);
});

test("refuses unit mismatch", () => {
  assert.deepEqual(calculateBolus(configuration, input({ glucoseUnit: "MG_DL" })), {
    status: "REFUSED", reasonCode: "UNIT_MISMATCH",
  });
});

test("refuses unconfirmed inputs", () => {
  assert.deepEqual(calculateBolus(configuration, input({ glucoseConfirmed: false })), {
    status: "REFUSED", reasonCode: "UNCONFIRMED_GLUCOSE",
  });
  assert.deepEqual(calculateBolus(configuration, input({ carbohydratesConfirmed: false })), {
    status: "REFUSED", reasonCode: "UNCONFIRMED_CARBOHYDRATES",
  });
});

test("refuses incomplete dose history", () => {
  assert.deepEqual(calculateBolus(configuration, input({ recentHistoryComplete: false })), {
    status: "REFUSED", reasonCode: "RECENT_BOLUS_HISTORY_INCOMPLETE",
  });
});

test("refuses duplicate-dose risk and special situations", () => {
  assert.deepEqual(calculateBolus(configuration, input({ duplicateDose: true })), {
    status: "REFUSED", reasonCode: "DUPLICATE_EVENT_RISK",
  });
  assert.deepEqual(calculateBolus(configuration, input({ specialSituations: ["SICK_DAY"] })), {
    status: "REFUSED", reasonCode: "SPECIAL_CLINICAL_SITUATION",
  });
});

test("rejects mode/carbohydrate inconsistency", () => {
  assert.deepEqual(calculateBolus(configuration, input({ mode: "MEAL", carbohydrateGrams: "0" })), {
    status: "REFUSED", reasonCode: "INVALID_INPUT",
  });
  assert.deepEqual(calculateBolus(configuration, input({ mode: "CORRECTION_ONLY", carbohydrateGrams: "1" })), {
    status: "REFUSED", reasonCode: "INVALID_INPUT",
  });
});

test("malformed decimals fail closed without returning a dose", () => {
  const result = calculateBolus(configuration, input({ currentGlucose: "1e1" }));
  assert.deepEqual(result, { status: "REFUSED", reasonCode: "INVALID_INPUT" });
  assert.equal("roundedDoseUnits" in result, false);
});

test("invalid clinician configuration fails closed", () => {
  const invalid = { ...configuration, targetGlucose: "4", lowGlucoseThreshold: "4" };
  assert.deepEqual(calculateBolus(invalid, input()), {
    status: "REFUSED", reasonCode: "INVALID_CONFIGURATION",
  });
});

test("determinism: repeated identical calls produce identical output", () => {
  const first = calculateBolus(configuration, input());
  for (let iteration = 0; iteration < 100; iteration += 1) {
    assert.deepEqual(calculateBolus(configuration, input()), first);
  }
});

test("property sweep: rounded dose is a non-negative multiple of increment", () => {
  for (let carbohydrate = 1; carbohydrate <= 150; carbohydrate += 1) {
    for (let glucoseTenths = 41; glucoseTenths <= 200; glucoseTenths += 7) {
      const result = calculateBolus(configuration, input({
        carbohydrateGrams: String(carbohydrate),
        currentGlucose: (glucoseTenths / 10).toFixed(1),
      }));
      if (result.status === "REFUSED") continue;
      const doubled = Number(result.roundedDoseUnits) * 2;
      assert.equal(Number.isInteger(doubled), true);
      assert.equal(Number(result.roundedDoseUnits) >= 0, true);
      assert.equal(Number(result.roundedDoseUnits) <= 20, true);
    }
  }
});
