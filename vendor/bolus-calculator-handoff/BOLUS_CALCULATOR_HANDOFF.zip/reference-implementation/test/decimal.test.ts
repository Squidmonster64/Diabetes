import assert from "node:assert/strict";
import test from "node:test";
import { Decimal } from "../src/decimal.js";

test("exact decimal addition avoids binary floating-point error", () => {
  const value = Decimal.parse("0.1").add(Decimal.parse("0.2"));
  assert.equal(value.toCanonicalString(), "0.3");
});

test("exact division and canonical output", () => {
  assert.equal(Decimal.parse("1").divide(Decimal.parse("4")).toCanonicalString(), "0.25");
});

test("half-up increment boundaries", () => {
  const increment = Decimal.parse("0.5");
  assert.equal(Decimal.parse("4.24").roundHalfUpToIncrement(increment).toCanonicalString(), "4");
  assert.equal(Decimal.parse("4.25").roundHalfUpToIncrement(increment).toCanonicalString(), "4.5");
  assert.equal(Decimal.parse("4.49").roundHalfUpToIncrement(increment).toCanonicalString(), "4.5");
});

test("rejects locale and exponent formats", () => {
  assert.throws(() => Decimal.parse("4,5"));
  assert.throws(() => Decimal.parse("1e2"));
  assert.throws(() => Decimal.parse("NaN"));
  assert.throws(() => Decimal.parse("Infinity"));
});
