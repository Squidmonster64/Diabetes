import assert from "node:assert/strict";
import test from "node:test";
import { BolusWorkflowService, InMemoryAppendOnlyAuditStore } from "../src/index.js";
import type { CalculationInput, ClinicianConfiguration, WorkflowVersions } from "../src/index.js";

const configuration: ClinicianConfiguration = {
  icr: "10", isf: "2", targetGlucose: "6", insulinDurationHours: "4",
  doseIncrementUnits: "0.5", maximumDoseUnits: "20", lowGlucoseThreshold: "4", glucoseUnit: "MMOL_L",
};
const versions: WorkflowVersions = { configurationId: "cfg-1", configurationVersion: 1, calculatorVersion: "0.4.0", safetyPolicyVersion: "0.5.0" };
function input(overrides: Partial<CalculationInput> = {}): CalculationInput {
  return { mode: "MEAL", currentGlucose: "10", glucoseUnit: "MMOL_L", glucoseConfirmed: true,
    carbohydrateGrams: "40", carbohydratesConfirmed: true, recentHistoryComplete: true,
    priorRapidActingDoses: [], hypoSymptoms: false, duplicateDose: false, specialSituations: [],
    calculatedAt: "2026-07-24T04:00:00.000Z", ...overrides };
}

test("successful calculation is audited before display and can be confirmed", () => {
  const audit = new InMemoryAppendOnlyAuditStore();
  const service = new BolusWorkflowService(audit);
  const created = service.createCalculation({ patientId: "patient-1", configuration, input: input(), versions });
  assert.equal(created.record.state, "CALCULATED");
  assert.ok(created.snapshotHash);
  assert.equal(audit.listForCalculation(created.record.calculationId).length, 2);
  const response = service.confirm({ calculationId: created.record.calculationId, patientId: "patient-1",
    confirmed: true, confirmationTextAccepted: true, confirmedAt: "2026-07-24T04:04:00.000Z", expectedSnapshotHash: created.snapshotHash! });
  assert.equal(response.ok, true);
  assert.equal(response.ok && response.record.state, "USER_CONFIRMED");
  assert.equal(audit.verifyChain(), true);
});

test("refusal is logged and exposes no display result", () => {
  const audit = new InMemoryAppendOnlyAuditStore();
  const created = new BolusWorkflowService(audit).createCalculation({ patientId: "p", configuration, input: input({ hypoSymptoms: true }), versions });
  assert.equal(created.record.state, "REFUSED");
  assert.equal(created.displayResult, undefined);
  assert.deepEqual(audit.listForCalculation(created.record.calculationId).map((e) => e.eventType), ["CALCULATION_STARTED", "CALCULATION_REFUSED"]);
});

test("confirmation expires after five minutes", () => {
  const service = new BolusWorkflowService(new InMemoryAppendOnlyAuditStore());
  const created = service.createCalculation({ patientId: "p", configuration, input: input(), versions });
  const response = service.confirm({ calculationId: created.record.calculationId, patientId: "p", confirmed: true,
    confirmationTextAccepted: true, confirmedAt: "2026-07-24T04:05:00.001Z", expectedSnapshotHash: created.snapshotHash! });
  assert.deepEqual(response, { ok: false, code: "CALCULATION_EXPIRED" });
  assert.equal(service.get(created.record.calculationId)?.state, "EXPIRED");
});

test("snapshot mismatch prevents confirmation", () => {
  const service = new BolusWorkflowService(new InMemoryAppendOnlyAuditStore());
  const created = service.createCalculation({ patientId: "p", configuration, input: input(), versions });
  assert.deepEqual(service.confirm({ calculationId: created.record.calculationId, patientId: "p", confirmed: true,
    confirmationTextAccepted: true, confirmedAt: "2026-07-24T04:01:00.000Z", expectedSnapshotHash: "tampered" }),
    { ok: false, code: "SNAPSHOT_MISMATCH" });
});

test("duplicate confirmation is rejected", () => {
  const service = new BolusWorkflowService(new InMemoryAppendOnlyAuditStore());
  const created = service.createCalculation({ patientId: "p", configuration, input: input(), versions });
  const request = { calculationId: created.record.calculationId, patientId: "p", confirmed: true as const,
    confirmationTextAccepted: true as const, confirmedAt: "2026-07-24T04:01:00.000Z", expectedSnapshotHash: created.snapshotHash! };
  assert.equal(service.confirm(request).ok, true);
  assert.deepEqual(service.confirm(request), { ok: false, code: "DUPLICATE_CONFIRMATION" });
});

test("input change invalidation blocks confirmation", () => {
  const service = new BolusWorkflowService(new InMemoryAppendOnlyAuditStore());
  const created = service.createCalculation({ patientId: "p", configuration, input: input(), versions });
  assert.equal(service.invalidate(created.record.calculationId, "p", "2026-07-24T04:01:00.000Z", "INPUT_CHANGED").ok, true);
  assert.deepEqual(service.confirm({ calculationId: created.record.calculationId, patientId: "p", confirmed: true,
    confirmationTextAccepted: true, confirmedAt: "2026-07-24T04:02:00.000Z", expectedSnapshotHash: created.snapshotHash! }),
    { ok: false, code: "CALCULATION_INVALIDATED" });
});

test("administration is separate and may differ from calculated dose", () => {
  const audit = new InMemoryAppendOnlyAuditStore();
  const service = new BolusWorkflowService(audit);
  const created = service.createCalculation({ patientId: "p", configuration, input: input(), versions });
  service.confirm({ calculationId: created.record.calculationId, patientId: "p", confirmed: true,
    confirmationTextAccepted: true, confirmedAt: "2026-07-24T04:01:00.000Z", expectedSnapshotHash: created.snapshotHash! });
  const response = service.recordAdministration({ calculationId: created.record.calculationId, patientId: "p",
    administeredUnits: "5.5", administeredAt: "2026-07-24T04:02:00.000Z" });
  assert.equal(response.ok && response.record.state, "ADMINISTRATION_RECORDED");
  const event = audit.listForCalculation(created.record.calculationId).at(-1)!;
  assert.deepEqual(event.payload, { administeredUnits: "5.5", calculatedUnits: "6" });
});

test("patient mismatch is rejected", () => {
  const service = new BolusWorkflowService(new InMemoryAppendOnlyAuditStore());
  const created = service.createCalculation({ patientId: "p1", configuration, input: input(), versions });
  assert.deepEqual(service.confirm({ calculationId: created.record.calculationId, patientId: "p2", confirmed: true,
    confirmationTextAccepted: true, confirmedAt: "2026-07-24T04:01:00.000Z", expectedSnapshotHash: created.snapshotHash! }),
    { ok: false, code: "PATIENT_MISMATCH" });
});
