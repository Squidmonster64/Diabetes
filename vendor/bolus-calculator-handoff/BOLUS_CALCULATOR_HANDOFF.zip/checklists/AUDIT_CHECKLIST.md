# Clinical Bolus Calculator — Audit Checklist

## Document and version control

- [ ] Intended-use statement is versioned and approved.
- [ ] Settings schema version is recorded.
- [ ] Calculator version is recorded.
- [ ] Safety-policy version is recorded.
- [ ] API/schema version is recorded.
- [ ] Release artefact has a reproducible hash.
- [ ] Every source and test file has a recorded SHA-256 hash.

## Settings provenance

- [ ] Configuration is linked to one patient.
- [ ] Configuration was created or imported by an authorised clinical role.
- [ ] Approval identity and timestamp are present where direct clinical approval applies.
- [ ] DIA provenance records patient transcription from clinician consultation or report.
- [ ] DIA source date/reference and patient accuracy-confirmation timestamp are present.
- [ ] A changed DIA creates a new settings version.
- [ ] Effective, expiry, superseded and revoked timestamps are present where applicable.
- [ ] Only one active configuration exists per patient.
- [ ] Active configuration is immutable.
- [ ] Integrity checksum or signature validates before calculation.
- [ ] No clinical defaults are shipped.

## Calculation trace

- [ ] Raw input snapshot is immutable.
- [ ] Glucose value, unit, source and measurement timestamp are recorded.
- [ ] Carbohydrate grams and confirmation provenance are recorded.
- [ ] Recent rapid-acting dose history and completeness affirmation are recorded.
- [ ] All safety declarations are recorded.
- [ ] Meal, correction, active-insulin adjustment, unrounded and rounded components are recorded.
- [ ] Maximum-dose comparison is recorded.
- [ ] Refusal has no hidden numerical dose.
- [ ] Calculator and settings versions are recorded.

## Confirmation trace

- [ ] Review snapshot hash is recorded.
- [ ] Confirmation wording acceptance is explicit.
- [ ] Confirmation time is within the review window.
- [ ] Patient identity matches.
- [ ] Duplicate confirmation is blocked.
- [ ] Input changes invalidate the preview.
- [ ] Confirmation is distinct from administration.
- [ ] Actual administered dose may differ and is stored separately.

## Audit integrity

- [ ] Calculation start is logged.
- [ ] Refusal or completion is logged before display.
- [ ] Confirmation, expiry, invalidation and administration are separate events.
- [ ] Events are append-only.
- [ ] Event sequence, previous hash and event hash are stored.
- [ ] Tampering, deletion and reordering tests pass.
- [ ] Durable transactional persistence is verified.
- [ ] Multi-writer/concurrency behavior is verified.
- [ ] Audit persistence failure prevents dose display.

## Verification and release

- [ ] Unit and property tests pass.
- [ ] Safety-gate tests cover every refusal code.
- [ ] Independent clinician golden dataset passes.
- [ ] mmol/L and mg/dL cases pass.
- [ ] Boundary tests cover threshold, target, duration, rounding and maximum.
- [ ] Human-factors testing is complete.
- [ ] Security and RLS tests pass.
- [ ] Regulatory pathway is documented.
- [ ] Formal risk-management file is approved.
- [ ] Final release decision is signed.
