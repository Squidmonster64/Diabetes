# Bolus Calculator Implementation Handoff

This compact package reconstructs the six-stage clinician-supplied bolus-calculator project without access to the original chat.

## Start here

Read:

`BOLUS_CALCULATOR_IMPLEMENTATION_HANDOFF.md`

## Contents

- `reference-implementation/` — exact Stage 5 TypeScript source and tests.
- `api-examples/` — consolidated request, success, refusal, confirmation and patient-entered DIA settings JSON.
- `test-fixtures/` — deterministic fixtures, including marked release-gap cases.
- `checklists/CLINICIAN_REVIEW_CHECKLIST.md` — completed Stage 6 checklist.
- `checklists/AUDIT_CHECKLIST.md` — implementation and release audit controls.
- `evidence/` — Stage 5 test/typecheck output, hashes, traceability and risk CSVs.

## Important design rule

The current design does not calculate or subtract insulin-on-board. The patient enters DIA from current clinician consultation advice or a clinician-provided report, confirms accurate transcription, and the value is versioned. Any prior rapid-acting dose within that DIA blocks the calculation.

## Reference verification

```bash
cd reference-implementation
npm test
npm run check
```

Node `>=22` is specified by the reference package.

## Status

Engineering handoff only. Not clinically approved and not release-ready.
